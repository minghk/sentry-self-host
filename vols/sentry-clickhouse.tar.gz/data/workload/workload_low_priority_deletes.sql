CREATE WORKLOAD low_priority_deletes IN `all` SETTINGS priority = 100, max_requests = 2, max_threads = 4
