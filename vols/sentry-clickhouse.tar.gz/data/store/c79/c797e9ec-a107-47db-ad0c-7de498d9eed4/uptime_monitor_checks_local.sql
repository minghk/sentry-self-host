ATTACH TABLE _ UUID 'b65f3ee4-2f31-41f8-8fa0-d673495fc2de'
(
    `organization_id` UInt64,
    `project_id` UInt64,
    `environment` LowCardinality(Nullable(String)),
    `uptime_subscription_id` UUID,
    `uptime_check_id` UUID,
    `scheduled_check_time` DateTime64(3),
    `timestamp` DateTime64(3),
    `duration_ms` UInt64,
    `region_slug` LowCardinality(String),
    `check_status` LowCardinality(String),
    `check_status_reason` LowCardinality(String),
    `http_status_code` Nullable(UInt16),
    `trace_id` UUID,
    `retention_days` UInt16
)
ENGINE = ReplacingMergeTree
PARTITION BY (retention_days, toMonday(timestamp))
ORDER BY (organization_id, project_id, toDateTime(timestamp), trace_id, uptime_check_id)
TTL toDateTime(timestamp) + toIntervalDay(retention_days)
SETTINGS index_granularity = 8192
