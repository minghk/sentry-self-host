ATTACH TABLE _ UUID 'c9669f0d-bf53-4396-ae4e-6191a6a44762'
(
    `project_id` UInt64,
    `metric_id` UInt64,
    `tag_key` UInt64,
    `tag_value` String,
    `timestamp` DateTime CODEC(DoubleDelta),
    `retention_days` UInt16,
    `count` AggregateFunction(sum, Float64)
)
ENGINE = AggregatingMergeTree
PARTITION BY toMonday(timestamp)
PRIMARY KEY (project_id, metric_id, tag_key, tag_value, timestamp)
ORDER BY (project_id, metric_id, tag_key, tag_value, timestamp)
TTL timestamp + toIntervalDay(retention_days)
SETTINGS index_granularity = 8192, ttl_only_drop_parts = 0
