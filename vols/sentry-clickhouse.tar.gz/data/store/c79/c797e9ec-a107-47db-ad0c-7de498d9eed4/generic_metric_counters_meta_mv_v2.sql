ATTACH MATERIALIZED VIEW _ UUID '116b9736-f2fc-4ede-9143-b088f72ce5ad' TO default.generic_metric_counters_meta_local
(
    `org_id` UInt64,
    `project_id` UInt64,
    `use_case_id` LowCardinality(String),
    `metric_id` UInt64,
    `tag_key` UInt64,
    `timestamp` DateTime CODEC(DoubleDelta),
    `retention_days` UInt16,
    `count` AggregateFunction(sum, Float64)
)
AS SELECT
    org_id,
    project_id,
    use_case_id,
    metric_id,
    tag_key,
    toMonday(timestamp) AS timestamp,
    retention_days,
    sumState(count_value) AS count
FROM default.generic_metric_counters_raw_local
LEFT ARRAY JOIN tags.key AS tag_key
WHERE record_meta = 1
GROUP BY
    org_id,
    project_id,
    use_case_id,
    metric_id,
    tag_key,
    timestamp,
    retention_days
