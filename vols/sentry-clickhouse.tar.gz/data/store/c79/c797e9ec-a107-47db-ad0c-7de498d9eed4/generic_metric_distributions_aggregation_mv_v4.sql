ATTACH MATERIALIZED VIEW _ UUID '84935057-f8e8-4136-92b2-daf10e59478c' TO default.generic_metric_distributions_aggregated_local
(
    `org_id` UInt64,
    `project_id` UInt64,
    `metric_id` UInt64,
    `granularity` UInt8,
    `timestamp` DateTime CODEC(DoubleDelta),
    `retention_days` UInt16,
    `tags.key` Array(UInt64),
    `tags.indexed_value` Array(UInt64),
    `tags.raw_value` Array(String),
    `value` AggregateFunction(uniqCombined64, UInt64),
    `use_case_id` LowCardinality(String)
)
AS SELECT
    org_id,
    project_id,
    metric_id,
    granularity,
    toDateTime(multiIf(granularity = 0, 10, granularity = 1, 60, granularity = 2, 3600, granularity = 3, 86400, -1) * intDiv(toUnixTimestamp(timestamp), multiIf(granularity = 0, 10, granularity = 1, 60, granularity = 2, 3600, granularity = 3, 86400, -1))) AS timestamp,
    least(retention_days, multiIf(granularity = 0, decasecond_retention_days, granularity = 1, min_retention_days, granularity = 2, hr_retention_days, granularity = 3, day_retention_days, 0)) AS retention_days,
    tags.key,
    tags.indexed_value,
    tags.raw_value,
    use_case_id,
    quantilesStateArrayIf(0.5, 0.75, 0.9, 0.95, 0.99)(distribution_values, disable_percentiles = 0) AS percentiles,
    quantilesTDigestWeightedStateArrayIf(0.5, 0.75, 0.9, 0.95, 0.99)(distribution_values, arrayWithConstant(length(distribution_values) AS distribution_length, sampling_weight) AS sampling_weight_array, disable_percentiles = 0) AS percentiles_weighted,
    minStateArray(distribution_values) AS min,
    maxStateArray(distribution_values) AS max,
    avgStateArray(distribution_values) AS avg,
    avgWeightedStateArray(distribution_values, sampling_weight_array) AS avg_weighted,
    sumStateArray(distribution_values) AS sum,
    sumStateArray(arrayMap(x -> (x * sampling_weight), distribution_values)) AS sum_weighted,
    countStateArray(distribution_values) AS count,
    sumState(distribution_length * sampling_weight) AS count_weighted,
    histogramStateArrayIf(250)(distribution_values, (disable_percentiles = 0) AND enable_histogram) AS histogram_buckets
FROM default.generic_metric_distributions_raw_local
ARRAY JOIN granularities AS granularity
WHERE (materialization_version = 4) AND (metric_type = 'distribution')
GROUP BY
    org_id,
    project_id,
    metric_id,
    granularity,
    timestamp,
    retention_days,
    tags.key,
    tags.indexed_value,
    tags.raw_value,
    use_case_id
