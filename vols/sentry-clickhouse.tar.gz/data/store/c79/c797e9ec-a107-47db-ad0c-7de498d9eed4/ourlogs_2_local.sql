ATTACH TABLE _ UUID '9bb23628-2ca1-4fe6-9902-7255345ead17'
(
    `organization_id` UInt64,
    `project_id` UInt64,
    `trace_id` UUID,
    `span_id` UInt64,
    `severity_text` String,
    `severity_number` UInt8,
    `retention_days` UInt16,
    `timestamp` DateTime64(9),
    `body` String CODEC(ZSTD(1)),
    `attr_string` Map(String, String),
    `attr_int` Map(String, Int64),
    `attr_double` Map(String, Float64),
    `attr_bool` Map(String, UInt8)
)
ENGINE = MergeTree
PARTITION BY (retention_days, toMonday(timestamp))
ORDER BY (organization_id, project_id, toDateTime(timestamp), trace_id)
TTL toDateTime(timestamp) + toIntervalDay(retention_days)
SETTINGS index_granularity = 8192
