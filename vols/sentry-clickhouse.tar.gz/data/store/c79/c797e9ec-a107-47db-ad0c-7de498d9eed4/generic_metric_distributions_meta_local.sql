ATTACH TABLE _ UUID 'c323b15d-95c6-47d8-acc2-219a0b81ce3e'
(
    `org_id` UInt64,
    `project_id` UInt64,
    `use_case_id` LowCardinality(String),
    `metric_id` UInt64,
    `tag_key` UInt64,
    `timestamp` DateTime CODEC(DoubleDelta),
    `retention_days` UInt16,
    `count` AggregateFunction(sum, Float64)
)
ENGINE = AggregatingMergeTree
PARTITION BY toMonday(timestamp)
PRIMARY KEY (org_id, project_id, use_case_id, metric_id, tag_key, timestamp)
ORDER BY (org_id, project_id, use_case_id, metric_id, tag_key, timestamp)
TTL timestamp + toIntervalDay(retention_days)
SETTINGS index_granularity = 8192, ttl_only_drop_parts = 0
