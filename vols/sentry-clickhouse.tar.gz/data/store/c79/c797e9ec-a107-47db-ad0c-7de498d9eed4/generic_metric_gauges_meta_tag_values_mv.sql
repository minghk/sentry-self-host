ATTACH MATERIALIZED VIEW _ UUID '2e79c41a-df6c-4058-956f-f5e11e98aea8' TO default.generic_metric_gauges_meta_tag_values_local
(
    `project_id` UInt64,
    `metric_id` UInt64,
    `tag_key` UInt64,
    `tag_value` String,
    `timestamp` DateTime CODEC(DoubleDelta),
    `retention_days` UInt16,
    `count` AggregateFunction(sum, Float64)
)
AS SELECT
    project_id,
    metric_id,
    tag_key,
    tag_value,
    toMonday(timestamp) AS timestamp,
    retention_days,
    sumState(count_value) AS count
FROM default.generic_metric_gauges_raw_local
ARRAY JOIN
    tags.key AS tag_key,
    tags.raw_value AS tag_value
WHERE record_meta = 1
GROUP BY
    project_id,
    metric_id,
    tag_key,
    tag_value,
    timestamp,
    retention_days
