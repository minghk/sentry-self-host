ATTACH MATERIALIZED VIEW _ UUID 'adc64146-a7f9-4a52-8534-88ad47159d0b' TO default.generic_metric_gauges_aggregated_local
(
    `org_id` UInt64,
    `project_id` UInt64,
    `metric_id` UInt64,
    `granularity` UInt8,
    `timestamp` DateTime CODEC(DoubleDelta),
    `retention_days` UInt16,
    `tags.key` Array(UInt64),
    `tags.indexed_value` Array(UInt64),
    `tags.raw_value` Array(String),
    `use_case_id` LowCardinality(String)
)
AS SELECT
    use_case_id,
    org_id,
    project_id,
    metric_id,
    arrayJoin(granularities) AS granularity,
    tags.key,
    tags.indexed_value,
    tags.raw_value,
    maxState(timestamp AS raw_timestamp) AS last_timestamp,
    toDateTime(multiIf(granularity = 0, 10, granularity = 1, 60, granularity = 2, 3600, granularity = 3, 86400, -1) * intDiv(toUnixTimestamp(raw_timestamp), multiIf(granularity = 0, 10, granularity = 1, 60, granularity = 2, 3600, granularity = 3, 86400, -1))) AS rounded_timestamp,
    least(retention_days, multiIf(granularity = 0, decasecond_retention_days, granularity = 1, min_retention_days, granularity = 2, hr_retention_days, granularity = 3, day_retention_days, 0)) AS retention_days,
    minState(arrayJoin(gauges_values.min)) AS min,
    maxState(arrayJoin(gauges_values.max)) AS max,
    sumState(arrayJoin(gauges_values.sum)) AS sum,
    sumState(arrayJoin(gauges_values.count)) AS count,
    argMaxState(arrayJoin(gauges_values.last), raw_timestamp) AS last
FROM default.generic_metric_gauges_raw_local
WHERE (materialization_version = 2) AND (metric_type = 'gauge')
GROUP BY
    use_case_id,
    org_id,
    project_id,
    metric_id,
    tags.key,
    tags.indexed_value,
    tags.raw_value,
    raw_timestamp,
    granularity,
    retention_days
