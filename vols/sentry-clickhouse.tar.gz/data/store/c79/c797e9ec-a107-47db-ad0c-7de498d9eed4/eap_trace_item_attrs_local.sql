ATTACH TABLE _ UUID 'e117a9fc-65ec-49bc-b623-f89fe36cb346'
(
    `project_id` UInt64,
    `item_type` String,
    `date` Date CODEC(DoubleDelta, ZSTD(1)),
    `retention_days` UInt16,
    `attrs_string` Map(String, String),
    `_str_attr_keys_hashes` Array(UInt64) MATERIALIZED arrayMap(k -> cityHash64(k), mapKeys(attrs_string)),
    `attrs_bool` Array(String),
    `attrs_int64` Array(String),
    `attrs_float64` Array(String),
    `_float64_attr_keys_hashes` Array(UInt64) MATERIALIZED arrayMap(k -> cityHash64(k), attrs_float64),
    `key_val_hash` UInt64,
    INDEX bf__str_attr_keys_hashes _str_attr_keys_hashes TYPE bloom_filter GRANULARITY 1,
    INDEX bf__float64_attr_keys_hashes _float64_attr_keys_hashes TYPE bloom_filter GRANULARITY 1
)
ENGINE = ReplacingMergeTree
PARTITION BY (retention_days, toMonday(date))
PRIMARY KEY (project_id, date, key_val_hash)
ORDER BY (project_id, date, key_val_hash)
TTL date + toIntervalDay(retention_days)
SETTINGS index_granularity = 8192
