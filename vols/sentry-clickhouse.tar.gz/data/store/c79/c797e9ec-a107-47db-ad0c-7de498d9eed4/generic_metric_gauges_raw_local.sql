ATTACH TABLE _ UUID '67e67b72-1cf3-4af3-944f-dd8e6e0d3357'
(
    `use_case_id` LowCardinality(String),
    `org_id` UInt64,
    `project_id` UInt64,
    `metric_id` UInt64,
    `timestamp` DateTime,
    `retention_days` UInt16,
    `tags.key` Array(UInt64),
    `tags.indexed_value` Array(UInt64),
    `tags.raw_value` Array(String),
    `set_values` Array(UInt64),
    `count_value` Float64,
    `distribution_values` Array(Float64),
    `gauges_values.last` Array(Float64),
    `gauges_values.min` Array(Float64),
    `gauges_values.max` Array(Float64),
    `gauges_values.sum` Array(Float64),
    `gauges_values.count` Array(UInt64),
    `metric_type` LowCardinality(String),
    `materialization_version` UInt8,
    `record_meta` UInt8 DEFAULT 0,
    `timeseries_id` UInt32,
    `partition` UInt16,
    `offset` UInt64,
    `granularities` Array(UInt8),
    `decasecond_retention_days` UInt8 DEFAULT 7,
    `min_retention_days` UInt8 DEFAULT 30,
    `hr_retention_days` UInt8 DEFAULT retention_days,
    `day_retention_days` UInt8 DEFAULT retention_days,
    `sampling_weight` UInt64 DEFAULT 1 CODEC(ZSTD(1))
)
ENGINE = MergeTree
PARTITION BY toStartOfInterval(timestamp, toIntervalDay(3))
ORDER BY (use_case_id, org_id, project_id, metric_id, timestamp)
TTL timestamp + toIntervalDay(7)
SETTINGS index_granularity = 8192
