ATTACH TABLE _ UUID 'd21f98a5-6d03-4d17-9bd7-385a98131538'
(
    `project_id` UInt64,
    `metric_id` UInt64,
    `tag_key` UInt64,
    `tag_value` String,
    `timestamp` DateTime CODEC(DoubleDelta),
    `retention_days` UInt16,
    `count` AggregateFunction(sum, Float64)
)
ENGINE = AggregatingMergeTree
PARTITION BY toMonday(timestamp)
PRIMARY KEY (project_id, metric_id, tag_key, tag_value, timestamp)
ORDER BY (project_id, metric_id, tag_key, tag_value, timestamp)
TTL timestamp + toIntervalDay(retention_days)
SETTINGS index_granularity = 8192, ttl_only_drop_parts = 0
