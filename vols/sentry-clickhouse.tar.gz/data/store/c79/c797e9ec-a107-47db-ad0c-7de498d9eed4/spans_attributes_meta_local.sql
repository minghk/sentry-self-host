ATTACH TABLE _ UUID 'cac6f88b-17be-4363-a4c6-e3be74e69853'
(
    `organization_id` UInt64,
    `attribute_type` String,
    `attribute_key` String,
    `attribute_value` String,
    `timestamp` DateTime CODEC(DoubleDelta),
    `retention_days` UInt16,
    `count` AggregateFunction(sum, UInt64)
)
ENGINE = AggregatingMergeTree
PARTITION BY toMonday(timestamp)
PRIMARY KEY (organization_id, attribute_key)
ORDER BY (organization_id, attribute_key, attribute_value, timestamp)
TTL timestamp + toIntervalDay(retention_days)
SETTINGS index_granularity = 8192, ttl_only_drop_parts = 0
