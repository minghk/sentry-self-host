ATTACH TABLE _ UUID '24e1f023-2327-4d9a-bc59-0d30eb09562f'
(
    `organization_id` UInt64,
    `project_id` UInt64,
    `environment` LowCardinality(Nullable(String)),
    `uptime_subscription_id` UUID,
    `uptime_check_id` UUID,
    `scheduled_check_time` DateTime,
    `timestamp` DateTime64(3),
    `duration_ms` UInt64,
    `region` LowCardinality(String),
    `check_status` LowCardinality(String),
    `check_status_reason` LowCardinality(String),
    `http_status_code` Nullable(UInt16),
    `trace_id` UUID,
    `retention_days` UInt16,
    `incident_status` UInt16
)
ENGINE = ReplacingMergeTree
PARTITION BY (retention_days, toMonday(scheduled_check_time))
ORDER BY (organization_id, project_id, scheduled_check_time, trace_id, uptime_check_id)
TTL toDateTime(timestamp) + toIntervalDay(retention_days)
SETTINGS index_granularity = 8192
