ATTACH TABLE _ UUID '11386e3c-68da-403b-a2fe-78e81ee9c27c'
(
    `org_id` UInt64,
    `project_id` UInt64,
    `use_case_id` LowCardinality(String),
    `metric_id` UInt64,
    `tag_key` UInt64,
    `timestamp` DateTime CODEC(DoubleDelta),
    `retention_days` UInt16,
    `count` AggregateFunction(sum, Float64)
)
ENGINE = AggregatingMergeTree
PARTITION BY toMonday(timestamp)
PRIMARY KEY (org_id, project_id, use_case_id, metric_id, tag_key, timestamp)
ORDER BY (org_id, project_id, use_case_id, metric_id, tag_key, timestamp)
TTL timestamp + toIntervalDay(retention_days)
SETTINGS index_granularity = 8192, ttl_only_drop_parts = 0
